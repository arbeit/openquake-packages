package org.gem.engine.hazard.parsers.japan;

public class CharSubdEqkSource {

}
