Note: These expected results were not computed by hand, but they have been checked
by Damiano Monelli and they are considered to be reasonable results. At this point,
we cannot say if they are 100% correct.
