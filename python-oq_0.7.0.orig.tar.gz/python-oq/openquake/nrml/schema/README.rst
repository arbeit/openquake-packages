
OpenQuake NRML schema
===================


Documentation

THIS DOCUMENTATION HAS MOVED
Thanks for checking out and hopefully contributing to the NRML documentation. 
The contents of this file have been moved to docs/source/schema.rst
