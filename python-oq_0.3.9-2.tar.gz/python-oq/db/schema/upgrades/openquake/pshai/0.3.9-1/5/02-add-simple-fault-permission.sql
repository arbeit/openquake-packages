GRANT SELECT ON pshai.simple_fault_geo_view TO GROUP openquake;
