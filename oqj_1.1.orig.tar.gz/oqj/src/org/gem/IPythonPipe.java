package org.gem;

public interface IPythonPipe {
    // public void write(char output);

    public void write(String output);
}
