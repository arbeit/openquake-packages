"""
Ostensibly core computation methods for hazard engine. Most of the hard
computation is backed by the Java HazardEngine via the hazard_wrapper
"""

import openquake.hazard.opensha
