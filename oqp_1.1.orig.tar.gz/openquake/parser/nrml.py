# -*- coding: utf-8 -*-
# vim: tabstop=4 shiftwidth=4 softtabstop=4

"""
This module contains common stuff for parsing NRML instance files.
"""

# TODO(fab): collect common stuff for all parsers here
