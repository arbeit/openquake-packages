"""A variety of file format parsers, including many of our 
internally defined NRML format, in both XML and YAML. Also
parsers for well-known ESRI binary and ascii formats."""