=================================
 Celery - Distributed Task Queue
=================================

Contents:

.. toctree::
    :maxdepth: 2

    getting-started/index
    userguide/index

.. toctree::
    :maxdepth: 1

    configuration
    cookbook/index
    contributing
    community
    tutorials/index
    faq
    changelog
    reference/index
    internals/index


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

