=============================
 celery.result
=============================

.. contents::
    :local:
.. currentmodule:: celery.result

.. automodule:: celery.result
    :members:
    :undoc-members:
