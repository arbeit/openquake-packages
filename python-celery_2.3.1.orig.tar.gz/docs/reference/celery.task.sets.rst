======================================================
 celery.task.sets
======================================================

.. contents::
    :local:
.. currentmodule:: celery.task.sets

.. automodule:: celery.task.sets
    :members:
    :undoc-members:
