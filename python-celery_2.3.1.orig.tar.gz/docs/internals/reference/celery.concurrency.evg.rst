=============================================================
 celery.concurrency.evg† (*experimental*)
=============================================================

.. contents::
    :local:
.. currentmodule:: celery.concurrency.evg

.. automodule:: celery.concurrency.evg
    :members:
    :undoc-members:
