=========================================
 celery.utils.dispatch
=========================================

.. contents::
    :local:
.. currentmodule:: celery.utils.dispatch

.. automodule:: celery.utils.dispatch
    :members:
    :undoc-members:
