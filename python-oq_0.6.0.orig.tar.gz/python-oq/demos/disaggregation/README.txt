This demo provides an example of a Disaggregation calculation.

The source model logic tree contains only one source (for active shallow crust):
a square area source, with sides of 1 degree length. The middle point of the square
is at 0.0 lat and 0.0 lon.

The GMPE logic tree contains only one GMPE (Boore and Atkinson 2008).

Disaggregation is computed at the square middle point all disaggregation results are
produced.