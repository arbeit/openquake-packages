Source model consisting of a single area source (PEER test "AREA 1" model)
