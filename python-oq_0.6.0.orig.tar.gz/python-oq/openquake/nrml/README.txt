Natural Hazard's Risk Markup Language (NRML)

This project contains schema definitions and tools for building
and manipulating NRML XML artifacts.
