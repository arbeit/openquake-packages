====================================
 Worker State - celery.worker.state
====================================

.. contents::
    :local:
.. currentmodule:: celery.worker.state

.. automodule:: celery.worker.state
    :members:
    :undoc-members:
