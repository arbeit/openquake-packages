==================================================================
 Remote Control Command Registry - celery.worker.control.registry
==================================================================

.. contents::
    :local:
.. currentmodule:: celery.worker.control.registry

.. automodule:: celery.worker.control.registry
    :members:
    :undoc-members:
