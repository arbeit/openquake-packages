===================================================================
 Built-in Remote Control Commands - celery.worker.control.builtins
===================================================================

.. contents::
    :local:

.. currentmodule:: celery.worker.control.builtins

.. automodule:: celery.worker.control.builtins
    :members:
    :undoc-members:
