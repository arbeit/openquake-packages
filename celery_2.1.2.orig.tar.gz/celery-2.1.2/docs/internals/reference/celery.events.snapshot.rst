==========================================
 Event Snapshots - celery.events.snapshot
==========================================

.. contents::
    :local:
.. currentmodule:: celery.events.snapshot

.. automodule:: celery.events.snapshot
    :members:
    :undoc-members:
