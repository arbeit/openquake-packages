============================================
 Compatibility Patches - celery.utils.patch
============================================

.. contents::
    :local:
.. currentmodule:: celery.utils.patch

.. automodule:: celery.utils.patch
    :members:
    :undoc-members:
