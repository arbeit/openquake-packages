===================================================================
 Thread Pool Support **EXPERIMENTAL** - celery.concurrency.threads
===================================================================

.. contents::
    :local:
.. currentmodule:: celery.concurrency.threads

.. automodule:: celery.concurrency.threads
    :members:
    :undoc-members:
