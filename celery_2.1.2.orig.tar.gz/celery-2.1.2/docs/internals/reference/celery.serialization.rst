============================================
 Serialization Tools - celery.serialization
============================================

.. contents::
    :local:
.. currentmodule:: celery.serialization

.. automodule:: celery.serialization
    :members:
    :undoc-members:
