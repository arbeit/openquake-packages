=================
 Getting Started
=================

:Release: |version|
:Date: |today|

.. toctree::
    :maxdepth: 2

    introduction
    broker-installation
    first-steps-with-celery
    resources
