=========================================
 Default Loader - celery.loaders.default
=========================================

.. contents::
    :local:
.. currentmodule:: celery.loaders.default

.. automodule:: celery.loaders.default
    :members:
    :undoc-members:
