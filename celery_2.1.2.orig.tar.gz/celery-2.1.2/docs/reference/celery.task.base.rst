===================================
 Defining Tasks - celery.task.base
===================================

.. contents::
    :local:
.. currentmodule:: celery.task.base

.. automodule:: celery.task.base
    :members: Task, PeriodicTask, TaskType
